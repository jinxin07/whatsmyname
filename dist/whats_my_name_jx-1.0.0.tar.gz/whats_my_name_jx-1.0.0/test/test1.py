import sys
sys.path.insert(0, "../main/")
import name
def test_the_name():
    print(name.whats_my_name())

test_the_name()

